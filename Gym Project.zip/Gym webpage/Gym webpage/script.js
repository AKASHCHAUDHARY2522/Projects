// let menu_icon = document.getElementById('menu-icon');
// let menu = document.querySelector('.nav-list');

// function showmenu(){
//     menu.style.display = 'block';
// }
// function hidemenu(){
//     menu.style.display = 'none';
// }